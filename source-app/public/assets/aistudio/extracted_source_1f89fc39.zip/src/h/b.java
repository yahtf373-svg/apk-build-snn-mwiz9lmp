package h;

/* loaded from: classes.dex */
public final class b extends RuntimeException {
}
