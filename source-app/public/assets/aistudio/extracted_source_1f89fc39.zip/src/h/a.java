package h;

import java.io.Serializable;

/* loaded from: classes.dex */
public final class a implements Serializable {

    /* renamed from: a, reason: collision with root package name */
    public final Object f128a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f129b;

    public a(Object obj, Serializable serializable) {
        this.f128a = obj;
        this.f129b = serializable;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return c.b.a(this.f128a, aVar.f128a) && c.b.a(this.f129b, aVar.f129b);
    }

    public final int hashCode() {
        Object obj = this.f128a;
        int hashCode = (obj == null ? 0 : obj.hashCode()) * 31;
        Object obj2 = this.f129b;
        return hashCode + (obj2 != null ? obj2.hashCode() : 0);
    }

    public final String toString() {
        return "(" + this.f128a + ", " + this.f129b + ')';
    }
}
