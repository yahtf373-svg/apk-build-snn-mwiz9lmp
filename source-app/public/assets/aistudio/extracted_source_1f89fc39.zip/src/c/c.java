package c;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final Object f44a = "/assets/";

    /* renamed from: b, reason: collision with root package name */
    public final Object f45b;

    public c(e.a aVar) {
        this.f45b = aVar;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return a.a(cVar.f44a, this.f44a) && a.a(cVar.f45b, this.f45b);
    }

    public final int hashCode() {
        Object obj = this.f44a;
        int hashCode = obj == null ? 0 : obj.hashCode();
        Object obj2 = this.f45b;
        return (obj2 != null ? obj2.hashCode() : 0) ^ hashCode;
    }

    public final String toString() {
        return "Pair{" + this.f44a + " " + this.f45b + "}";
    }
}
