package c;

import android.content.Context;
import android.content.Intent;
import com.abdullah.sunan.AlarmPage;
import com.abdullah.sunan.Ring;
import g.t;
import i.g;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

/* loaded from: classes.dex */
public abstract class b {
    public static boolean a(Object obj, Object obj2) {
        return obj == null ? obj2 == null : obj.equals(obj2);
    }

    public static void b(Object obj, String str) {
        if (obj != null) {
            return;
        }
        NullPointerException nullPointerException = new NullPointerException(str.concat(" must not be null"));
        h(nullPointerException);
        throw nullPointerException;
    }

    public static void c(Object obj, String str) {
        if (obj == null) {
            StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
            String name = b.class.getName();
            int i2 = 0;
            while (!stackTrace[i2].getClassName().equals(name)) {
                i2++;
            }
            while (stackTrace[i2].getClassName().equals(name)) {
                i2++;
            }
            StackTraceElement stackTraceElement = stackTrace[i2];
            NullPointerException nullPointerException = new NullPointerException("Parameter specified as non-null is null: method " + stackTraceElement.getClassName() + "." + stackTraceElement.getMethodName() + ", parameter " + str);
            h(nullPointerException);
            throw nullPointerException;
        }
    }

    public static double d(double d2) {
        return (d2 * 3.141592653589793d) / 180.0d;
    }

    public static t e(int i2, int i3, int i4, double d2, double d3) {
        int i5;
        int i6 = i3;
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(i2, i6 - 1, i4, 0, 0, 0);
        long timeInMillis = calendar.getTimeInMillis();
        double offset = TimeZone.getDefault().getOffset(43200000 + timeInMillis) / 3600000.0d;
        if (i6 <= 2) {
            i5 = i2 - 1;
            i6 += 12;
        } else {
            i5 = i2;
        }
        double floor = Math.floor(i5 / 100.0d);
        double d4 = 2;
        double floor2 = ((((((Math.floor((i6 + 1) * 30.6001d) + Math.floor((i5 + 4716) * 365.25d)) + i4) + (Math.floor(floor / 4) + (d4 - floor))) - 1524.5d) + 0.5d) - (d3 / 360.0d)) - 2451545.0d;
        double d5 = ((((0.98560028d * floor2) + 357.529d) % 360.0d) + 360.0d) % 360.0d;
        double d6 = ((((0.98564736d * floor2) + 280.459d) % 360.0d) + 360.0d) % 360.0d;
        double sin = ((((Math.sin(d(d4 * d5)) * 0.02d) + ((Math.sin(d(d5)) * 1.915d) + d6)) % 360.0d) + 360.0d) % 360.0d;
        double d7 = 23.439d - (floor2 * 3.6E-7d);
        double atan2 = (((((Math.atan2(Math.sin(d(sin)) * Math.cos(d(d7)), Math.cos(d(sin))) * 180.0d) / 3.141592653589793d) / 15.0d) % 24.0d) + 24.0d) % 24.0d;
        double asin = (Math.asin(Math.sin(d(sin)) * Math.sin(d(d7))) * 180.0d) / 3.141592653589793d;
        double d8 = (((((12 + offset) - (d3 / 15.0d)) - ((d6 / 15.0d) - atan2)) % 24.0d) + 24.0d) % 24.0d;
        double d9 = -((Math.atan(1.0d / (Math.tan(d(Math.abs(d2 - asin))) + 1.0d)) * 180.0d) / 3.141592653589793d);
        double f2 = d8 - f(asin, d2, 0.833d);
        double f3 = f(asin, d2, 0.833d) + d8;
        return new t(timeInMillis + ((long) ((d8 - f(asin, d2, 18.5d)) * 3600000.0d)), timeInMillis + ((long) (f2 * 3600000.0d)), ((long) ((0.016666666666666666d + d8) * 3600000.0d)) + timeInMillis, timeInMillis + ((long) ((d8 + f(asin, d2, d9)) * 3600000.0d)), timeInMillis + ((long) (f3 * 3600000.0d)), timeInMillis + ((long) ((f3 + 1.5d) * 3600000.0d)));
    }

    /* JADX WARN: Code restructure failed: missing block: B:8:0x0039, code lost:
    
        if (r8 > 1.0d) goto L4;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final double f(double r4, double r6, double r8) {
        /*
            double r8 = d(r8)
            double r8 = java.lang.Math.sin(r8)
            double r8 = -r8
            double r0 = d(r4)
            double r0 = java.lang.Math.sin(r0)
            double r2 = d(r6)
            double r2 = java.lang.Math.sin(r2)
            double r2 = r2 * r0
            double r8 = r8 - r2
            double r4 = d(r4)
            double r4 = java.lang.Math.cos(r4)
            double r6 = d(r6)
            double r6 = java.lang.Math.cos(r6)
            double r6 = r6 * r4
            double r8 = r8 / r6
            r4 = -4616189618054758400(0xbff0000000000000, double:-1.0)
            int r6 = (r8 > r4 ? 1 : (r8 == r4 ? 0 : -1))
            if (r6 >= 0) goto L35
        L33:
            r8 = r4
            goto L3c
        L35:
            r4 = 4607182418800017408(0x3ff0000000000000, double:1.0)
            int r6 = (r8 > r4 ? 1 : (r8 == r4 ? 0 : -1))
            if (r6 <= 0) goto L3c
            goto L33
        L3c:
            double r4 = java.lang.Math.acos(r8)
            r6 = 4640537203540230144(0x4066800000000000, double:180.0)
            double r4 = r4 * r6
            r6 = 4614256656552045848(0x400921fb54442d18, double:3.141592653589793)
            double r4 = r4 / r6
            r6 = 4624633867356078080(0x402e000000000000, double:15.0)
            double r4 = r4 / r6
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.f(double, double, double):double");
    }

    public static List g(Object... objArr) {
        if (objArr.length <= 0) {
            return g.f133a;
        }
        List asList = Arrays.asList(objArr);
        b(asList, "asList(...)");
        return asList;
    }

    public static void h(RuntimeException runtimeException) {
        String name = b.class.getName();
        StackTraceElement[] stackTrace = runtimeException.getStackTrace();
        int length = stackTrace.length;
        int i2 = -1;
        for (int i3 = 0; i3 < length; i3++) {
            if (name.equals(stackTrace[i3].getClassName())) {
                i2 = i3;
            }
        }
        runtimeException.setStackTrace((StackTraceElement[]) Arrays.copyOfRange(stackTrace, i2 + 1, length));
    }

    public static void i(Context context) {
        c(context, "c");
        try {
            context.stopService(new Intent(context, (Class<?>) Ring.class));
        } catch (Exception unused) {
        }
        AlarmPage alarmPage = AlarmPage.f46a;
        AlarmPage alarmPage2 = AlarmPage.f46a;
        if (alarmPage2 != null) {
            alarmPage2.finish();
        }
    }
}
