package i;

import java.util.Collection;

/* loaded from: classes.dex */
public abstract class b extends c.b {
    public static int j(Iterable iterable) {
        c.b.c(iterable, "<this>");
        if (iterable instanceof Collection) {
            return ((Collection) iterable).size();
        }
        return 10;
    }
}
