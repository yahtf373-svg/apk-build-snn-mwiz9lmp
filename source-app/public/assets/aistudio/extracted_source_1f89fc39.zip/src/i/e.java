package i;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public abstract class e extends d {
    public static ArrayList k(ArrayList arrayList, List list) {
        c.b.c(list, "<this>");
        ArrayList arrayList2 = new ArrayList(arrayList.size() + list.size());
        arrayList2.addAll(list);
        arrayList2.addAll(arrayList);
        return arrayList2;
    }

    public static final List l(List list) {
        int size = list.size();
        if (size == 0) {
            return g.f133a;
        }
        if (size != 1) {
            return new ArrayList(list);
        }
        List singletonList = Collections.singletonList(list.get(0));
        c.b.b(singletonList, "singletonList(...)");
        return singletonList;
    }
}
