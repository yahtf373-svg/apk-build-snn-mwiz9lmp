package i;

/* loaded from: classes.dex */
public abstract class c extends b {
}
