package i;

/* loaded from: classes.dex */
public abstract class d extends c {
}
