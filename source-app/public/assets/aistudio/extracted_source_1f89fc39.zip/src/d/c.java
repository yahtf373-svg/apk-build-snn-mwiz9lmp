package d;

import android.os.Parcel;
import android.util.SparseIntArray;

/* loaded from: classes.dex */
public final class c extends b {

    /* renamed from: d, reason: collision with root package name */
    public final SparseIntArray f63d;

    /* renamed from: e, reason: collision with root package name */
    public final Parcel f64e;

    /* renamed from: f, reason: collision with root package name */
    public final int f65f;

    /* renamed from: g, reason: collision with root package name */
    public final int f66g;

    /* renamed from: h, reason: collision with root package name */
    public final String f67h;

    /* renamed from: i, reason: collision with root package name */
    public int f68i;

    /* renamed from: j, reason: collision with root package name */
    public int f69j;

    /* renamed from: k, reason: collision with root package name */
    public int f70k;

    public c(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "", new a.b(), new a.b(), new a.b());
    }

    @Override // d.b
    public final c a() {
        Parcel parcel = this.f64e;
        int dataPosition = parcel.dataPosition();
        int i2 = this.f69j;
        if (i2 == this.f65f) {
            i2 = this.f66g;
        }
        return new c(parcel, dataPosition, i2, this.f67h + "  ", this.f60a, this.f61b, this.f62c);
    }

    @Override // d.b
    public final boolean e(int i2) {
        while (this.f69j < this.f66g) {
            int i3 = this.f70k;
            if (i3 == i2) {
                return true;
            }
            if (String.valueOf(i3).compareTo(String.valueOf(i2)) > 0) {
                return false;
            }
            int i4 = this.f69j;
            Parcel parcel = this.f64e;
            parcel.setDataPosition(i4);
            int readInt = parcel.readInt();
            this.f70k = parcel.readInt();
            this.f69j += readInt;
        }
        return this.f70k == i2;
    }

    @Override // d.b
    public final void h(int i2) {
        int i3 = this.f68i;
        SparseIntArray sparseIntArray = this.f63d;
        Parcel parcel = this.f64e;
        if (i3 >= 0) {
            int i4 = sparseIntArray.get(i3);
            int dataPosition = parcel.dataPosition();
            parcel.setDataPosition(i4);
            parcel.writeInt(dataPosition - i4);
            parcel.setDataPosition(dataPosition);
        }
        this.f68i = i2;
        sparseIntArray.put(i2, parcel.dataPosition());
        parcel.writeInt(0);
        parcel.writeInt(i2);
    }

    public c(Parcel parcel, int i2, int i3, String str, a.b bVar, a.b bVar2, a.b bVar3) {
        super(bVar, bVar2, bVar3);
        this.f63d = new SparseIntArray();
        this.f68i = -1;
        this.f70k = -1;
        this.f64e = parcel;
        this.f65f = i2;
        this.f66g = i3;
        this.f69j = i2;
        this.f67h = str;
    }
}
