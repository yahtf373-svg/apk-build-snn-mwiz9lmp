package a;

/* loaded from: classes.dex */
public abstract class c {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f12a = new int[0];

    /* renamed from: b, reason: collision with root package name */
    public static final Object[] f13b = new Object[0];
}
