package a;

import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class f implements Iterator, Map.Entry {

    /* renamed from: a, reason: collision with root package name */
    public int f21a;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ a f24d;

    /* renamed from: c, reason: collision with root package name */
    public boolean f23c = false;

    /* renamed from: b, reason: collision with root package name */
    public int f22b = -1;

    public f(a aVar) {
        this.f24d = aVar;
        this.f21a = aVar.f3d.f10c - 1;
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        if (!this.f23c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        if (!(obj instanceof Map.Entry)) {
            return false;
        }
        Map.Entry entry = (Map.Entry) obj;
        Object key = entry.getKey();
        int i2 = this.f22b;
        a aVar = this.f24d;
        Object a2 = aVar.a(i2, 0);
        if (key != a2 && (key == null || !key.equals(a2))) {
            return false;
        }
        Object value = entry.getValue();
        Object a3 = aVar.a(this.f22b, 1);
        return value == a3 || (value != null && value.equals(a3));
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        if (!this.f23c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        return this.f24d.a(this.f22b, 0);
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        if (!this.f23c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        return this.f24d.a(this.f22b, 1);
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f22b < this.f21a;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        if (!this.f23c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        int i2 = this.f22b;
        a aVar = this.f24d;
        Object a2 = aVar.a(i2, 0);
        Object a3 = aVar.a(this.f22b, 1);
        return (a2 == null ? 0 : a2.hashCode()) ^ (a3 != null ? a3.hashCode() : 0);
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        this.f22b++;
        this.f23c = true;
        return this;
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f23c) {
            throw new IllegalStateException();
        }
        this.f24d.b(this.f22b);
        this.f22b--;
        this.f21a--;
        this.f23c = false;
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        if (!this.f23c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        int i2 = (this.f22b << 1) + 1;
        Object[] objArr = this.f24d.f3d.f9b;
        Object obj2 = objArr[i2];
        objArr[i2] = obj;
        return obj2;
    }

    public final String toString() {
        return getKey() + "=" + getValue();
    }
}
