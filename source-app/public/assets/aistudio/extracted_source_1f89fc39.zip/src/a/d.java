package a;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class d implements Iterator {

    /* renamed from: a, reason: collision with root package name */
    public final int f14a;

    /* renamed from: b, reason: collision with root package name */
    public int f15b;

    /* renamed from: c, reason: collision with root package name */
    public int f16c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f17d = false;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ a f18e;

    public d(a aVar, int i2) {
        this.f18e = aVar;
        this.f14a = i2;
        this.f15b = aVar.f3d.f10c;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f16c < this.f15b;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        Object a2 = this.f18e.a(this.f16c, this.f14a);
        this.f16c++;
        this.f17d = true;
        return a2;
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f17d) {
            throw new IllegalStateException();
        }
        int i2 = this.f16c - 1;
        this.f16c = i2;
        this.f15b--;
        this.f17d = false;
        this.f18e.b(i2);
    }
}
