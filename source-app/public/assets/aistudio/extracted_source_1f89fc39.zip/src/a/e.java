package a;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.chromium.support_lib_boundary.WebSettingsBoundaryInterface;

/* loaded from: classes.dex */
public final class e implements Set {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f19a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ a f20b;

    public /* synthetic */ e(a aVar, int i2) {
        this.f19a = i2;
        this.f20b = aVar;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean add(Object obj) {
        switch (this.f19a) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                throw new UnsupportedOperationException();
            default:
                throw new UnsupportedOperationException();
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean addAll(Collection collection) {
        switch (this.f19a) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                a aVar = this.f20b;
                int i2 = aVar.f3d.f10c;
                Iterator it = collection.iterator();
                while (true) {
                    boolean hasNext = it.hasNext();
                    b bVar = aVar.f3d;
                    if (!hasNext) {
                        return i2 != bVar.f10c;
                    }
                    Map.Entry entry = (Map.Entry) it.next();
                    bVar.put(entry.getKey(), entry.getValue());
                }
            default:
                throw new UnsupportedOperationException();
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final void clear() {
        int i2 = this.f19a;
        a aVar = this.f20b;
        switch (i2) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                aVar.f3d.clear();
                break;
            default:
                aVar.f3d.clear();
                break;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean contains(Object obj) {
        int i2 = this.f19a;
        a aVar = this.f20b;
        switch (i2) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                if (obj instanceof Map.Entry) {
                    Map.Entry entry = (Map.Entry) obj;
                    int k2 = aVar.f3d.k(entry.getKey());
                    if (k2 >= 0) {
                        Object a2 = aVar.a(k2, 1);
                        Object value = entry.getValue();
                        if (a2 == value || (a2 != null && a2.equals(value))) {
                            break;
                        }
                    }
                }
                break;
            default:
                if (aVar.f3d.k(obj) >= 0) {
                    break;
                }
                break;
        }
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean containsAll(Collection collection) {
        switch (this.f19a) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                Iterator it = collection.iterator();
                while (it.hasNext()) {
                    if (!contains(it.next())) {
                        break;
                    }
                }
                break;
            default:
                b bVar = this.f20b.f3d;
                Iterator it2 = collection.iterator();
                while (it2.hasNext()) {
                    if (!bVar.containsKey(it2.next())) {
                        break;
                    }
                }
                break;
        }
        return false;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean equals(Object obj) {
        switch (this.f19a) {
        }
        return a.c(this, obj);
    }

    @Override // java.util.Set, java.util.Collection
    public final int hashCode() {
        int i2 = this.f19a;
        a aVar = this.f20b;
        switch (i2) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                int i3 = 0;
                for (int i4 = aVar.f3d.f10c - 1; i4 >= 0; i4--) {
                    Object a2 = aVar.a(i4, 0);
                    Object a3 = aVar.a(i4, 1);
                    i3 += (a2 == null ? 0 : a2.hashCode()) ^ (a3 == null ? 0 : a3.hashCode());
                }
                return i3;
            default:
                int i5 = 0;
                for (int i6 = aVar.f3d.f10c - 1; i6 >= 0; i6--) {
                    Object a4 = aVar.a(i6, 0);
                    i5 += a4 == null ? 0 : a4.hashCode();
                }
                return i5;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean isEmpty() {
        int i2 = this.f19a;
        a aVar = this.f20b;
        switch (i2) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                if (aVar.f3d.f10c == 0) {
                    break;
                }
                break;
            default:
                if (aVar.f3d.f10c == 0) {
                    break;
                }
                break;
        }
        return true;
    }

    @Override // java.util.Set, java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        int i2 = this.f19a;
        a aVar = this.f20b;
        switch (i2) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                return new f(aVar);
            default:
                return new d(aVar, 0);
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean remove(Object obj) {
        switch (this.f19a) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                throw new UnsupportedOperationException();
            default:
                a aVar = this.f20b;
                int k2 = aVar.f3d.k(obj);
                if (k2 < 0) {
                    return false;
                }
                aVar.b(k2);
                return true;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean removeAll(Collection collection) {
        switch (this.f19a) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                throw new UnsupportedOperationException();
            default:
                b bVar = this.f20b.f3d;
                int i2 = bVar.f10c;
                Iterator it = collection.iterator();
                while (it.hasNext()) {
                    bVar.remove(it.next());
                }
                return i2 != bVar.f10c;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean retainAll(Collection collection) {
        switch (this.f19a) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                throw new UnsupportedOperationException();
            default:
                b bVar = this.f20b.f3d;
                int i2 = bVar.f10c;
                Iterator it = ((e) bVar.keySet()).iterator();
                while (it.hasNext()) {
                    if (!collection.contains(it.next())) {
                        it.remove();
                    }
                }
                return i2 != bVar.f10c;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final int size() {
        int i2 = this.f19a;
        a aVar = this.f20b;
        switch (i2) {
        }
        return aVar.f3d.f10c;
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray() {
        switch (this.f19a) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                throw new UnsupportedOperationException();
            default:
                a aVar = this.f20b;
                int i2 = aVar.f3d.f10c;
                Object[] objArr = new Object[i2];
                for (int i3 = 0; i3 < i2; i3++) {
                    objArr[i3] = aVar.a(i3, 0);
                }
                return objArr;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        switch (this.f19a) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                throw new UnsupportedOperationException();
            default:
                return this.f20b.d(objArr, 0);
        }
    }
}
