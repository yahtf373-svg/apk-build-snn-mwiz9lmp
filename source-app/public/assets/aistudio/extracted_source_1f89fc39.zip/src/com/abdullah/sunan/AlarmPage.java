package com.abdullah.sunan;

import android.app.Activity;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import com.abdullah.sunan.AlarmPage;
import j.a;

/* loaded from: classes.dex */
public final class AlarmPage extends Activity {

    /* renamed from: a, reason: collision with root package name */
    public static volatile AlarmPage f46a;

    public static final Button a(AlarmPage alarmPage, float f2, String str, int i2, int i3, final a aVar) {
        Button button = new Button(alarmPage);
        button.setText(str);
        button.setTextSize(19.0f);
        button.setTextColor(i3);
        button.setAllCaps(false);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(22 * f2);
        gradientDrawable.setColor(i2);
        button.setBackground(gradientDrawable);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, (int) (62 * f2));
        layoutParams.topMargin = (int) (12 * f2);
        button.setLayoutParams(layoutParams);
        button.setOnClickListener(new View.OnClickListener() { // from class: g.g
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                AlarmPage alarmPage2 = AlarmPage.f46a;
                j.a aVar2 = j.a.this;
                c.b.c(aVar2, "$on");
                aVar2.a();
            }
        });
        return button;
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x0147, code lost:
    
        if (r7.equals("sabah") == false) goto L69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x0197, code lost:
    
        if (r7.equals("masa") == false) goto L69;
     */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void onCreate(android.os.Bundle r22) {
        /*
            Method dump skipped, instructions count: 882
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: com.abdullah.sunan.AlarmPage.onCreate(android.os.Bundle):void");
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        if (f46a == this) {
            f46a = null;
        }
        super.onDestroy();
    }
}
