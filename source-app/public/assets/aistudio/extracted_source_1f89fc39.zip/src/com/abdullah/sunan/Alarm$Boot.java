package com.abdullah.sunan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import c.b;
import g.e;

/* loaded from: classes.dex */
public final class Alarm$Boot extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        b.c(context, "c");
        b.c(intent, "i");
        e.f(context);
    }
}
