package com.abdullah.sunan;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import c.b;
import g.e;
import g.w;
import n.f;

/* loaded from: classes.dex */
public final class Alarm$Act extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        b.c(context, "c");
        b.c(intent, "i");
        String stringExtra = intent.getStringExtra("day");
        if (stringExtra == null) {
            return;
        }
        Ring ring = Ring.f50h;
        b.i(context);
        String stringExtra2 = intent.getStringExtra("snooze");
        if (stringExtra2 != null) {
            e.g(context, stringExtra2, stringExtra, 10);
        }
        String[] stringArrayExtra = intent.getStringArrayExtra("marks");
        if (stringArrayExtra == null) {
            stringArrayExtra = new String[0];
        }
        for (String str : stringArrayExtra) {
            if (str == null) {
                NullPointerException nullPointerException = new NullPointerException();
                b.h(nullPointerException);
                throw nullPointerException;
            }
            boolean o = f.o(str);
            w wVar = w.f127a;
            if (o) {
                String substring = str.substring(1);
                b.b(substring, "substring(...)");
                wVar.c(context, stringExtra, substring, -1);
            } else {
                wVar.c(context, stringExtra, str, 1);
            }
        }
        ((NotificationManager) context.getSystemService(NotificationManager.class)).cancel(intent.getIntExtra("nid", 0));
        MainActivity mainActivity = MainActivity.f47c;
        MainActivity mainActivity2 = MainActivity.f47c;
        if (mainActivity2 != null) {
            mainActivity2.b("window.onState&&onState()");
        }
    }
}
