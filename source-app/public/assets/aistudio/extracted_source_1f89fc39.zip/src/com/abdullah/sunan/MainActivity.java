package com.abdullah.sunan;

import android.app.Activity;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;
import c.c;
import com.abdullah.sunan.MainActivity;
import e.a;
import g.e;
import g.k;
import g.p;
import g.r;
import g.s;
import h.b;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class MainActivity extends Activity {

    /* renamed from: c, reason: collision with root package name */
    public static volatile MainActivity f47c;

    /* renamed from: a, reason: collision with root package name */
    public WebView f48a;

    /* renamed from: b, reason: collision with root package name */
    public final Handler f49b = new Handler(Looper.getMainLooper());

    public final WebView a() {
        WebView webView = this.f48a;
        if (webView != null) {
            return webView;
        }
        b bVar = new b("lateinit property web has not been initialized");
        c.b.h(bVar);
        throw bVar;
    }

    public final boolean b(String str) {
        c.b.c(str, "s");
        return this.f49b.post(new k(this, str, 0));
    }

    /* JADX WARN: Removed duplicated region for block: B:34:0x0071  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x007f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void c() {
        /*
            r12 = this;
            java.lang.Class<android.location.LocationManager> r0 = android.location.LocationManager.class
            java.lang.Object r0 = r12.getSystemService(r0)
            android.location.LocationManager r0 = (android.location.LocationManager) r0
            k.e r8 = new k.e
            r8.<init>()
            r1 = 1
            java.util.List r1 = r0.getProviders(r1)
            java.util.Iterator r1 = r1.iterator()
        L16:
            boolean r2 = r1.hasNext()
            r3 = 0
            if (r2 == 0) goto L3f
            java.lang.Object r2 = r1.next()
            java.lang.String r2 = (java.lang.String) r2
            android.location.Location r3 = r0.getLastKnownLocation(r2)     // Catch: java.lang.Exception -> L27
        L27:
            if (r3 != 0) goto L2a
            goto L16
        L2a:
            android.location.Location r2 = r8.f138a
            if (r2 == 0) goto L3c
            long r4 = r3.getTime()
            android.location.Location r2 = r8.f138a
            long r6 = r2.getTime()
            int r2 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r2 <= 0) goto L16
        L3c:
            r8.f138a = r3
            goto L16
        L3f:
            android.location.Location r1 = r8.f138a
            if (r1 == 0) goto L5b
            long r1 = java.lang.System.currentTimeMillis()
            android.location.Location r4 = r8.f138a
            long r4 = r4.getTime()
            long r1 = r1 - r4
            r4 = 1800000(0x1b7740, double:8.89318E-318)
            int r1 = (r1 > r4 ? 1 : (r1 == r4 ? 0 : -1))
            if (r1 >= 0) goto L5b
            android.location.Location r0 = r8.f138a
            r12.d(r0)
            return
        L5b:
            java.lang.String r1 = "network"
            boolean r2 = r0.isProviderEnabled(r1)
            if (r2 == 0) goto L65
        L63:
            r2 = r1
            goto L6f
        L65:
            java.lang.String r1 = "gps"
            boolean r2 = r0.isProviderEnabled(r1)
            if (r2 == 0) goto L6e
            goto L63
        L6e:
            r2 = r3
        L6f:
            if (r2 != 0) goto L7f
            android.location.Location r0 = r8.f138a
            if (r0 == 0) goto L79
            r12.d(r0)
            goto L7e
        L79:
            java.lang.String r0 = "onEv({ev:'loc',err:'off'})"
            r12.b(r0)
        L7e:
            return
        L7f:
            k.d r9 = new k.d
            r9.<init>()
            g.q r10 = new g.q
            r10.<init>(r9, r0, r12)
            r3 = 0
            r5 = 0
            android.os.Looper r7 = android.os.Looper.getMainLooper()     // Catch: java.lang.Exception -> L95
            r1 = r0
            r6 = r10
            r1.requestLocationUpdates(r2, r3, r5, r6, r7)     // Catch: java.lang.Exception -> L95
        L95:
            android.os.Handler r7 = r12.f49b
            g.l r11 = new g.l
            r1 = r11
            r2 = r9
            r3 = r0
            r4 = r10
            r5 = r8
            r6 = r12
            r1.<init>()
            r0 = 15000(0x3a98, double:7.411E-320)
            r7.postDelayed(r11, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.abdullah.sunan.MainActivity.c():void");
    }

    public final boolean d(Location location) {
        return b("onEv({ev:'loc',lat:" + location.getLatitude() + ",lon:" + location.getLongitude() + "})");
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
        a().evaluateJavascript("(window.onBack&&window.onBack())?'1':'0'", new ValueCallback() { // from class: g.m
            @Override // android.webkit.ValueCallback
            public final void onReceiveValue(Object obj) {
                String str = (String) obj;
                MainActivity mainActivity = MainActivity.f47c;
                MainActivity mainActivity2 = MainActivity.this;
                c.b.c(mainActivity2, "this$0");
                if (str == null || n.f.k(0, str, "1", false) < 0) {
                    mainActivity2.finish();
                }
            }
        });
    }

    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        f47c = this;
        e.b(this);
        e.f(this);
        ArrayList arrayList = new ArrayList();
        a aVar = new a();
        f.a aVar2 = new f.a();
        aVar2.f77a = this;
        aVar.f71a = aVar2;
        arrayList.add(new c(aVar));
        ArrayList arrayList2 = new ArrayList();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            c cVar = (c) it.next();
            arrayList2.add(new e.b((String) cVar.f44a, (a) cVar.f45b));
        }
        e.c cVar2 = new e.c(arrayList2);
        this.f48a = new WebView(this);
        a().setBackgroundColor(Color.parseColor("#071A1C"));
        WebSettings settings = a().getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setTextZoom(100);
        settings.setSupportZoom(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(-1);
        CookieManager.getInstance().setAcceptThirdPartyCookies(a(), true);
        a().setWebViewClient(new r(cVar2));
        a().setWebChromeClient(new s());
        a().addJavascriptInterface(new p(this), "SN");
        setContentView(a());
        a().loadUrl("https://appassets.androidplatform.net/assets/web/index.html");
    }

    @Override // android.app.Activity
    public final void onDestroy() {
        if (f47c == this) {
            f47c = null;
        }
        super.onDestroy();
    }

    @Override // android.app.Activity
    public final void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        c.b.c(strArr, "p");
        c.b.c(iArr, "g");
        if (i2 == 3) {
            e.f(this);
        }
        if (i2 == 5) {
            if ((!(iArr.length == 0)) && iArr[0] == 0) {
                c();
            } else {
                b("onEv({ev:'loc',err:'denied'})");
            }
        }
    }

    @Override // android.app.Activity
    public final void onResume() {
        super.onResume();
        f47c = this;
        b("window.onState&&onState()");
    }
}
