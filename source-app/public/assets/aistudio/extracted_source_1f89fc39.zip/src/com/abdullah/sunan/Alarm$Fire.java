package com.abdullah.sunan;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import c.b;
import g.e;

/* loaded from: classes.dex */
public final class Alarm$Fire extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        b.c(context, "c");
        b.c(intent, "i");
        String stringExtra = intent.getStringExtra("kind");
        String stringExtra2 = intent.getStringExtra("day");
        if (stringExtra != null && stringExtra2 != null) {
            e.e(context, stringExtra, stringExtra2);
        }
        if (intent.getBooleanExtra("snoozed", false)) {
            return;
        }
        e.f(context);
    }
}
