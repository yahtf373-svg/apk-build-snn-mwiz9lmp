package com.abdullah.sunan;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import c.b;
import g.c;
import g.e;
import g.v;
import java.util.List;

/* loaded from: classes.dex */
public final class Ring extends Service {

    /* renamed from: h, reason: collision with root package name */
    public static volatile Ring f50h = null;

    /* renamed from: i, reason: collision with root package name */
    public static volatile String f51i = "";

    /* renamed from: j, reason: collision with root package name */
    public static volatile String f52j = "";

    /* renamed from: b, reason: collision with root package name */
    public MediaPlayer f54b;

    /* renamed from: c, reason: collision with root package name */
    public Ringtone f55c;

    /* renamed from: d, reason: collision with root package name */
    public Vibrator f56d;

    /* renamed from: e, reason: collision with root package name */
    public long f57e;

    /* renamed from: f, reason: collision with root package name */
    public int f58f;

    /* renamed from: a, reason: collision with root package name */
    public final Handler f53a = new Handler(Looper.getMainLooper());

    /* renamed from: g, reason: collision with root package name */
    public final AudioAttributes f59g = new AudioAttributes.Builder().setUsage(4).setContentType(4).build();

    public final void a(int i2) {
        if (i2 != this.f58f) {
            return;
        }
        if (System.currentTimeMillis() - this.f57e > 120000) {
            List list = e.f86a;
            c h2 = e.h(this, f51i, f52j);
            stopForeground(1);
            if (h2 != null) {
                try {
                    ((NotificationManager) getSystemService(NotificationManager.class)).notify(e.d(f51i), e.a(this, "sunan", f51i, f52j, h2).build());
                } catch (SecurityException unused) {
                }
            }
            AlarmPage alarmPage = AlarmPage.f46a;
            AlarmPage alarmPage2 = AlarmPage.f46a;
            if (alarmPage2 != null) {
                alarmPage2.finish();
            }
            stopSelf();
            return;
        }
        if (i2 == this.f58f && this.f54b == null) {
            try {
                if (this.f55c == null) {
                    Uri actualDefaultRingtoneUri = RingtoneManager.getActualDefaultRingtoneUri(this, 4);
                    if (actualDefaultRingtoneUri == null) {
                        actualDefaultRingtoneUri = RingtoneManager.getActualDefaultRingtoneUri(this, 1);
                    }
                    if (actualDefaultRingtoneUri != null) {
                        Ringtone ringtone = RingtoneManager.getRingtone(this, actualDefaultRingtoneUri);
                        if (ringtone != null) {
                            ringtone.setAudioAttributes(new AudioAttributes.Builder().setUsage(4).build());
                        } else {
                            ringtone = null;
                        }
                        this.f55c = ringtone;
                    }
                }
                Ringtone ringtone2 = this.f55c;
                if (ringtone2 != null) {
                    ringtone2.play();
                }
            } catch (Exception unused2) {
                this.f55c = null;
            }
            Ringtone ringtone3 = this.f55c;
            if (ringtone3 != null && ringtone3.isPlaying()) {
                this.f53a.postDelayed(new v(this, i2, 0), 1000L);
                return;
            }
            try {
                this.f55c = null;
                MediaPlayer mediaPlayer = new MediaPlayer();
                mediaPlayer.setAudioAttributes(this.f59g);
                AssetFileDescriptor openRawResourceFd = getResources().openRawResourceFd(R.raw.alarm_beep);
                mediaPlayer.setDataSource(openRawResourceFd.getFileDescriptor(), openRawResourceFd.getStartOffset(), openRawResourceFd.getLength());
                openRawResourceFd.close();
                mediaPlayer.setLooping(true);
                mediaPlayer.prepare();
                mediaPlayer.start();
                this.f54b = mediaPlayer;
            } catch (Exception e2) {
                Log.w("sunan", "beep: " + e2);
            }
        }
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public final void onDestroy() {
        this.f58f++;
        this.f53a.removeCallbacksAndMessages(null);
        try {
            MediaPlayer mediaPlayer = this.f54b;
            if (mediaPlayer != null) {
                mediaPlayer.release();
            }
        } catch (Exception unused) {
        }
        this.f54b = null;
        try {
            Ringtone ringtone = this.f55c;
            if (ringtone != null) {
                ringtone.stop();
            }
        } catch (Exception unused2) {
        }
        try {
            Vibrator vibrator = this.f56d;
            if (vibrator != null) {
                vibrator.cancel();
            }
        } catch (Exception unused3) {
        }
        if (f50h == this) {
            f50h = null;
        }
        super.onDestroy();
    }

    @Override // android.app.Service
    public final int onStartCommand(Intent intent, int i2, int i3) {
        String stringExtra;
        String stringExtra2;
        if (intent == null || (stringExtra = intent.getStringExtra("kind")) == null || (stringExtra2 = intent.getStringExtra("day")) == null) {
            return 2;
        }
        c h2 = e.h(this, stringExtra, stringExtra2);
        if (h2 == null) {
            stopSelf();
            return 2;
        }
        f51i = stringExtra;
        f52j = stringExtra2;
        f50h = this;
        NotificationManager notificationManager = (NotificationManager) getSystemService(NotificationManager.class);
        if (notificationManager.getNotificationChannel("sunan_alarm") == null) {
            NotificationChannel notificationChannel = new NotificationChannel("sunan_alarm", "منبه السنن", 4);
            notificationChannel.setDescription("شاشة كاملة ورنّة زي المنبه");
            notificationChannel.setSound(null, null);
            notificationChannel.enableVibration(false);
            notificationChannel.setLockscreenVisibility(1);
            notificationChannel.setBypassDnd(false);
            notificationManager.createNotificationChannel(notificationChannel);
        }
        PendingIntent activity = PendingIntent.getActivity(this, 9, new Intent(this, (Class<?>) AlarmPage.class).addFlags(268697600), 201326592);
        Notification.Builder contentIntent = e.a(this, "sunan_alarm", stringExtra, stringExtra2, h2).setOngoing(true).setAutoCancel(false).setCategory("alarm").setFullScreenIntent(activity, true).setContentIntent(activity);
        b.b(contentIntent, "setContentIntent(...)");
        if (h2.f84d.size() < 3) {
            Intent putExtra = new Intent(this, (Class<?>) Alarm$Act.class).putExtra("day", stringExtra2).putExtra("snooze", stringExtra).putExtra("nid", e.d(stringExtra));
            b.b(putExtra, "putExtra(...)");
            PendingIntent broadcast = PendingIntent.getBroadcast(this, stringExtra.concat("snooze").hashCode(), putExtra, 201326592);
            b.b(broadcast, "getBroadcast(...)");
            contentIntent.addAction(new Notification.Action.Builder((Icon) null, "⏰ بعد ١٠ د", broadcast).build());
        }
        Notification build = contentIntent.build();
        b.b(build, "build(...)");
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(e.d(stringExtra), build, 2);
            } else {
                startForeground(e.d(stringExtra), build);
            }
            try {
                startActivity(new Intent(this, (Class<?>) AlarmPage.class).addFlags(268435456));
            } catch (Exception unused) {
            }
            this.f57e = System.currentTimeMillis();
            int i4 = this.f58f + 1;
            this.f58f = i4;
            a(i4);
            long[] jArr = {0, 600, 500, 600, 1500};
            Vibrator vibrator = (Vibrator) getSystemService(Vibrator.class);
            this.f56d = vibrator;
            if (vibrator != null) {
                try {
                    vibrator.vibrate(VibrationEffect.createWaveform(jArr, 0));
                } catch (Exception unused2) {
                }
            }
            return 2;
        } catch (Exception e2) {
            Log.w("sunan", "startForeground: " + e2);
            stopSelf();
            return 2;
        }
    }
}
