package k;

import java.io.Serializable;

/* loaded from: classes.dex */
public abstract class c implements Serializable {
    public final String toString() {
        f.f139a.getClass();
        String obj = getClass().getGenericInterfaces()[0].toString();
        if (obj.startsWith("kotlin.jvm.functions.")) {
            obj = obj.substring(21);
        }
        c.b.b(obj, "renderLambdaToString(...)");
        return obj;
    }
}
