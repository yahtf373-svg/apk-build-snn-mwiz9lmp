package k;

import android.location.Location;
import java.io.Serializable;

/* loaded from: classes.dex */
public final class e implements Serializable {

    /* renamed from: a, reason: collision with root package name */
    public Location f138a;

    public final String toString() {
        return String.valueOf(this.f138a);
    }
}
