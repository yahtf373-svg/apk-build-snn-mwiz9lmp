package m;

import java.util.Iterator;

/* loaded from: classes.dex */
public final class b implements Iterable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ a f148a;

    public b(n.b bVar) {
        this.f148a = bVar;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        n.b bVar = (n.b) this.f148a;
        bVar.getClass();
        return new n.a(bVar);
    }
}
