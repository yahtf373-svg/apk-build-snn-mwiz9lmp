package n;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class a implements Iterator {

    /* renamed from: a, reason: collision with root package name */
    public int f149a = -1;

    /* renamed from: b, reason: collision with root package name */
    public int f150b;

    /* renamed from: c, reason: collision with root package name */
    public int f151c;

    /* renamed from: d, reason: collision with root package name */
    public l.c f152d;

    /* renamed from: e, reason: collision with root package name */
    public int f153e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ b f154f;

    public a(b bVar) {
        this.f154f = bVar;
        int length = bVar.f155a.length();
        if (length < 0) {
            throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + length + " is less than minimum 0.");
        }
        int i2 = bVar.f156b;
        if (i2 < 0) {
            length = 0;
        } else if (i2 <= length) {
            length = i2;
        }
        this.f150b = length;
        this.f151c = length;
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x001d, code lost:
    
        if (r9 < r4) goto L9;
     */
    /* JADX WARN: Removed duplicated region for block: B:26:0x010a  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x011f  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0133  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void a() {
        /*
            Method dump skipped, instructions count: 354
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: n.a.a():void");
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        if (this.f149a == -1) {
            a();
        }
        return this.f149a == 1;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (this.f149a == -1) {
            a();
        }
        if (this.f149a == 0) {
            throw new NoSuchElementException();
        }
        l.c cVar = this.f152d;
        if (cVar != null) {
            this.f152d = null;
            this.f149a = -1;
            return cVar;
        }
        NullPointerException nullPointerException = new NullPointerException("null cannot be cast to non-null type kotlin.ranges.IntRange");
        c.b.h(nullPointerException);
        throw nullPointerException;
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
