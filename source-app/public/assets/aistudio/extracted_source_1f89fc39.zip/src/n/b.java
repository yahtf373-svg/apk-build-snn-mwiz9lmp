package n;

/* loaded from: classes.dex */
public final class b implements m.a {

    /* renamed from: a, reason: collision with root package name */
    public final CharSequence f155a;

    /* renamed from: b, reason: collision with root package name */
    public final int f156b;

    /* renamed from: c, reason: collision with root package name */
    public final int f157c;

    /* renamed from: d, reason: collision with root package name */
    public final e f158d;

    public b(CharSequence charSequence, int i2, int i3, e eVar) {
        c.b.c(charSequence, "input");
        this.f155a = charSequence;
        this.f156b = i2;
        this.f157c = i3;
        this.f158d = eVar;
    }
}
