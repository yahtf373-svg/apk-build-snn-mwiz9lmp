package n;

import java.util.List;

/* loaded from: classes.dex */
public final class e extends k.c {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ List f159a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ boolean f160b;

    public e(List list, boolean z) {
        this.f159a = list;
        this.f160b = z;
    }
}
