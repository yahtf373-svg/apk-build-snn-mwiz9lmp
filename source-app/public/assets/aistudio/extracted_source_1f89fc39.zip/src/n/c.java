package n;

/* loaded from: classes.dex */
public abstract class c extends i.b {
}
