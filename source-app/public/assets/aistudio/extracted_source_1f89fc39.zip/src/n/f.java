package n;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public abstract class f extends d {
    public static final int k(int i2, CharSequence charSequence, String str, boolean z) {
        c.b.c(charSequence, "<this>");
        c.b.c(str, "string");
        if (!z && (charSequence instanceof String)) {
            return ((String) charSequence).indexOf(str, i2);
        }
        int length = charSequence.length();
        if (i2 < 0) {
            i2 = 0;
        }
        int length2 = charSequence.length();
        if (length > length2) {
            length = length2;
        }
        l.c cVar = new l.c(i2, length, 1);
        boolean z2 = charSequence instanceof String;
        int i3 = cVar.f141b;
        if (z2) {
            if (i2 <= i3) {
                while (!l(str, (String) charSequence, i2, str.length(), z)) {
                    if (i2 != i3) {
                        i2++;
                    }
                }
                return i2;
            }
        } else if (i2 <= i3) {
            while (!m(str, charSequence, i2, str.length(), z)) {
                if (i2 != i3) {
                    i2++;
                }
            }
            return i2;
        }
        return -1;
    }

    public static final boolean l(String str, String str2, int i2, int i3, boolean z) {
        c.b.c(str, "<this>");
        c.b.c(str2, "other");
        return !z ? str.regionMatches(0, str2, i2, i3) : str.regionMatches(z, 0, str2, i2, i3);
    }

    public static final boolean m(CharSequence charSequence, CharSequence charSequence2, int i2, int i3, boolean z) {
        char upperCase;
        char upperCase2;
        c.b.c(charSequence, "<this>");
        c.b.c(charSequence2, "other");
        if (i2 < 0 || charSequence.length() - i3 < 0 || i2 > charSequence2.length() - i3) {
            return false;
        }
        for (int i4 = 0; i4 < i3; i4++) {
            char charAt = charSequence.charAt(i4);
            char charAt2 = charSequence2.charAt(i2 + i4);
            if (charAt != charAt2 && (!z || ((upperCase = Character.toUpperCase(charAt)) != (upperCase2 = Character.toUpperCase(charAt2)) && Character.toLowerCase(upperCase) != Character.toLowerCase(upperCase2)))) {
                return false;
            }
        }
        return true;
    }

    public static List n(CharSequence charSequence, String[] strArr) {
        c.b.c(charSequence, "<this>");
        if (strArr.length == 1) {
            String str = strArr[0];
            if (str.length() != 0) {
                int k2 = k(0, charSequence, str, false);
                if (k2 == -1) {
                    List singletonList = Collections.singletonList(charSequence.toString());
                    c.b.b(singletonList, "singletonList(...)");
                    return singletonList;
                }
                ArrayList arrayList = new ArrayList(10);
                int i2 = 0;
                do {
                    arrayList.add(charSequence.subSequence(i2, k2).toString());
                    i2 = str.length() + k2;
                    k2 = k(i2, charSequence, str, false);
                } while (k2 != -1);
                arrayList.add(charSequence.subSequence(i2, charSequence.length()).toString());
                return arrayList;
            }
        }
        List asList = Arrays.asList(strArr);
        c.b.b(asList, "asList(...)");
        m.b bVar = new m.b(new b(charSequence, 0, 0, new e(asList, false)));
        ArrayList arrayList2 = new ArrayList(i.b.j(bVar));
        Iterator it = bVar.iterator();
        while (true) {
            a aVar = (a) it;
            if (!aVar.hasNext()) {
                return arrayList2;
            }
            l.c cVar = (l.c) aVar.next();
            arrayList2.add(charSequence.subSequence(Integer.valueOf(cVar.f140a).intValue(), Integer.valueOf(cVar.f141b).intValue() + 1).toString());
        }
    }

    public static boolean o(String str) {
        c.b.c(str, "<this>");
        return str.startsWith("-");
    }
}
