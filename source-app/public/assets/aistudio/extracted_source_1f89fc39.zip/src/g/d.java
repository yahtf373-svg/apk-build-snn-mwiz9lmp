package g;

import java.util.Comparator;

/* loaded from: classes.dex */
public final class d implements Comparator {
    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        Long valueOf = Long.valueOf(((b) obj).f78a);
        Long valueOf2 = Long.valueOf(((b) obj2).f78a);
        if (valueOf == valueOf2) {
            return 0;
        }
        if (valueOf == null) {
            return -1;
        }
        if (valueOf2 == null) {
            return 1;
        }
        return valueOf.compareTo(valueOf2);
    }
}
