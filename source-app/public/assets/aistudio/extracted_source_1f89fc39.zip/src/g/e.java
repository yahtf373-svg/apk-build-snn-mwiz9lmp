package g;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.util.Log;
import com.abdullah.sunan.Alarm$Act;
import com.abdullah.sunan.Alarm$Fire;
import com.abdullah.sunan.MainActivity;
import com.abdullah.sunan.R;
import com.abdullah.sunan.Ring;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.json.JSONObject;

/* loaded from: classes.dex */
public abstract class e {

    /* renamed from: a, reason: collision with root package name */
    public static final List f86a = c.b.g("dhA", "mag", "isha");

    /* renamed from: b, reason: collision with root package name */
    public static final List f87b = c.b.g("fajr", "dhB", "witr", "duha", "asr4", "qiyam", "wudu", "tahiya", "jamaa", "takbir");

    /* renamed from: c, reason: collision with root package name */
    public static final List f88c = c.b.g("salat", "nawm", "mulk", "istig", "salawat", "adhan", "tardid", "tahlil", "tasbih", "wird", "thuluth", "siyam");

    /* renamed from: d, reason: collision with root package name */
    public static final List f89d = c.b.g("fajr", "dhuhr", "asr4", "maghrib", "isha", "comp", "duha", "witr", "sabah", "masa", "kahf", "jumua", "nawm", "compZ", "siyamR");

    public static Notification.Builder a(Context context, String str, String str2, String str3, c cVar) {
        List<h.a> list;
        c.b.c(context, "c");
        c.b.c(str2, "kind");
        c.b.c(str3, "day");
        Notification.Builder contentText = new Notification.Builder(context, str).setSmallIcon(R.drawable.ic_note).setContentIntent(PendingIntent.getActivity(context, 2, new Intent(context, (Class<?>) MainActivity.class).addFlags(536870912), 201326592)).setAutoCancel(true).setColor(cVar.f83c).setContentTitle(cVar.f81a).setContentText(cVar.f82b);
        c.b.b(contentText, "setContentText(...)");
        List list2 = cVar.f84d;
        c.b.c(list2, "<this>");
        if (3 >= list2.size()) {
            list = i.e.l(list2);
        } else {
            ArrayList arrayList = new ArrayList(3);
            Iterator it = list2.iterator();
            int i2 = 0;
            while (it.hasNext()) {
                arrayList.add(it.next());
                i2++;
                if (i2 == 3) {
                    break;
                }
            }
            int size = arrayList.size();
            if (size == 0) {
                list = i.g.f133a;
            } else if (size != 1) {
                list = arrayList;
            } else {
                list = Collections.singletonList(arrayList.get(0));
                c.b.b(list, "singletonList(...)");
            }
        }
        for (h.a aVar : list) {
            String str4 = (String) aVar.f128a;
            String[] strArr = (String[]) aVar.f129b;
            c.b.c(str4, "label");
            c.b.c(strArr, "marks");
            Intent putExtra = new Intent(context, (Class<?>) Alarm$Act.class).putExtra("day", str3).putExtra("marks", strArr).putExtra("nid", d(str2));
            c.b.b(putExtra, "putExtra(...)");
            PendingIntent broadcast = PendingIntent.getBroadcast(context, str2.concat(str4).hashCode(), putExtra, 201326592);
            c.b.b(broadcast, "getBroadcast(...)");
            contentText.addAction(new Notification.Action.Builder((Icon) null, str4, broadcast).build());
        }
        return contentText;
    }

    public static void b(Context context) {
        c.b.c(context, "c");
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(NotificationManager.class);
        if (notificationManager.getNotificationChannel("sunan") == null) {
            NotificationChannel notificationChannel = new NotificationChannel("sunan", "تذكير السنن والأذكار", 4);
            notificationChannel.setDescription("بعد كل صلاة: صليت السنة؟ وتذكير الأذكار");
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    public static boolean c(String str) {
        List n2 = n.f.n(str, new String[]{"-"});
        Calendar calendar = Calendar.getInstance();
        calendar.set(Integer.parseInt((String) n2.get(0)), Integer.parseInt((String) n2.get(1)) - 1, Integer.parseInt((String) n2.get(2)), 12, 0);
        return calendar.get(7) == 6;
    }

    public static int d(String str) {
        c.b.c(str, "kind");
        return f89d.indexOf(str) + 100;
    }

    public static void e(Context context, String str, String str2) {
        c.b.c(context, "c");
        c.b.c(str, "kind");
        c.b.c(str2, "day");
        b(context);
        c h2 = h(context, str, str2);
        if (h2 == null) {
            return;
        }
        w wVar = w.f127a;
        if ((!c.b.a(wVar.b(context).optString("mode", "alarm"), "alarm") || !(!h2.f84d.isEmpty())) && (!c.b.a(wVar.b(context).optString("mode", "alarm"), "alarm") || !c.b.a(str, "siyamR"))) {
            try {
                ((NotificationManager) context.getSystemService(NotificationManager.class)).notify(d(str), a(context, "sunan", str, str2, h2).build());
                return;
            } catch (SecurityException unused) {
                return;
            }
        }
        Ring ring = Ring.f50h;
        Intent putExtra = new Intent(context, (Class<?>) Ring.class).putExtra("kind", str).putExtra("day", str2);
        c.b.b(putExtra, "putExtra(...)");
        try {
            context.startForegroundService(putExtra);
        } catch (Exception e2) {
            Log.w("sunan", "ring fgs failed: " + e2);
            c h3 = h(context, str, str2);
            if (h3 == null) {
                return;
            }
            try {
                ((NotificationManager) context.getSystemService(NotificationManager.class)).notify(d(str), a(context, "sunan", str, str2, h3).build());
            } catch (SecurityException unused2) {
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v11 */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v24 */
    /* JADX WARN: Type inference failed for: r1v8, types: [int] */
    public static void f(Context context) {
        AlarmManager alarmManager;
        Class<Alarm$Fire> cls;
        b bVar;
        boolean canScheduleExactAlarms;
        List asList;
        Object obj;
        int k2;
        c.b.c(context, "c");
        AlarmManager alarmManager2 = (AlarmManager) context.getSystemService(AlarmManager.class);
        Class<Alarm$Fire> cls2 = Alarm$Fire.class;
        int i2 = 1;
        alarmManager2.cancel(PendingIntent.getBroadcast(context, 1, new Intent(context, cls2), 201326592));
        w wVar = w.f127a;
        if (wVar.b(context).optBoolean("notif", true)) {
            long currentTimeMillis = System.currentTimeMillis() + 1000;
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(currentTimeMillis);
            int i3 = 5;
            calendar.add(5, -1);
            int i4 = 0;
            while (true) {
                if (i4 >= 4) {
                    alarmManager = alarmManager2;
                    cls = cls2;
                    bVar = null;
                    break;
                }
                int i5 = calendar.get(i2);
                int i6 = calendar.get(2);
                int i7 = i6 + 1;
                int i8 = calendar.get(i3);
                JSONObject optJSONObject = wVar.b(context).optJSONObject("loc");
                int i9 = i4;
                double optDouble = optJSONObject != null ? optJSONObject.optDouble("lat", 24.4672d) : 24.4672d;
                JSONObject optJSONObject2 = wVar.b(context).optJSONObject("loc");
                t e2 = c.b.e(i5, i7, i8, optDouble, optJSONObject2 != null ? optJSONObject2.optDouble("lon", 39.6111d) : 39.6111d);
                long optInt = wVar.b(context).optInt("off", 35) * 60000;
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                long j2 = e2.f120c;
                String format = simpleDateFormat.format(new Date(j2));
                c.b.b(format, "format(...)");
                List a2 = wVar.a(context);
                alarmManager = alarmManager2;
                b bVar2 = new b(j2 + optInt, "dhuhr", format);
                long j3 = currentTimeMillis;
                long j4 = e2.f122e;
                w wVar2 = wVar;
                cls = cls2;
                b bVar3 = new b(j4 + optInt, "maghrib", format);
                long j5 = e2.f123f;
                ArrayList arrayList = new ArrayList(new i.a(new b[]{bVar2, bVar3, new b(j5 + optInt, "isha", format), new b((110 * 60000) + j5, "comp", format)}));
                if (a2.contains("fajr")) {
                    arrayList.add(new b(e2.f118a + optInt, "fajr", format));
                }
                if (a2.contains("asr4")) {
                    arrayList.add(new b(e2.f121d + optInt, "asr4", format));
                }
                if (a2.contains("duha")) {
                    long j6 = e2.f119b;
                    arrayList.add(new b(((j2 - j6) / 2) + j6, "duha", format));
                }
                if (a2.contains("witr")) {
                    arrayList.add(new b((75 * 60000) + j5, "witr", format));
                }
                if (wVar2.b(context).optBoolean("azkarOn", false)) {
                    JSONObject b2 = wVar2.b(context);
                    Calendar calendar2 = Calendar.getInstance();
                    calendar2.clear();
                    calendar2.set(i5, i6, i8, 0, 0);
                    arrayList.add(new b((b2.optInt("sabahAt", 480) * 60000) + calendar2.getTimeInMillis(), "sabah", format));
                    arrayList.add(new b(c.b.a(b2.optString("masaAt"), "adhan") ? j4 : j4 - (15 * 60000), "masa", format));
                    if (c(format)) {
                        arrayList.add(new b((600 * 60000) + calendar2.getTimeInMillis(), "kahf", format));
                        arrayList.add(new b(j4 - (60 * 60000), "jumua", format));
                    }
                    if (a2.contains("nawm") || a2.contains("mulk")) {
                        arrayList.add(new b((150 * 60000) + j5, "nawm", format));
                    }
                    if (a2.contains("siyam") && ((k2 = k(format)) == 1 || k2 == 4)) {
                        arrayList.add(new b((30 * 60000) + j5, "siyamR", format));
                    }
                    arrayList.add(new b((100 * 60000) + j5, "compZ", format));
                }
                d dVar = new d();
                if (arrayList.size() <= 1) {
                    asList = i.e.l(arrayList);
                } else {
                    Object[] array = arrayList.toArray(new Object[0]);
                    c.b.c(array, "<this>");
                    if (array.length > 1) {
                        Arrays.sort(array, dVar);
                    }
                    asList = Arrays.asList(array);
                    c.b.b(asList, "asList(...)");
                }
                Iterator it = asList.iterator();
                while (true) {
                    if (!it.hasNext()) {
                        obj = null;
                        break;
                    }
                    Object next = it.next();
                    if (((b) next).f78a > j3) {
                        obj = next;
                        break;
                    }
                }
                bVar = (b) obj;
                if (bVar != null) {
                    break;
                }
                calendar.add(5, 1);
                i4 = i9 + 1;
                wVar = wVar2;
                i3 = 5;
                alarmManager2 = alarmManager;
                currentTimeMillis = j3;
                cls2 = cls;
                i2 = 1;
            }
            if (bVar == null) {
                return;
            }
            Intent putExtra = new Intent(context, cls).putExtra("kind", bVar.f79b).putExtra("day", bVar.f80c);
            c.b.b(putExtra, "putExtra(...)");
            PendingIntent broadcast = PendingIntent.getBroadcast(context, 1, putExtra, 201326592);
            AlarmManager alarmManager3 = Build.VERSION.SDK_INT;
            int i10 = 31;
            long j7 = bVar.f78a;
            try {
                if (alarmManager3 >= 31) {
                    canScheduleExactAlarms = alarmManager.canScheduleExactAlarms();
                    if (!canScheduleExactAlarms) {
                        AlarmManager alarmManager4 = alarmManager;
                        i10 = 0;
                        alarmManager4.setAndAllowWhileIdle(0, j7, broadcast);
                        alarmManager3 = alarmManager4;
                    }
                }
                AlarmManager alarmManager5 = alarmManager;
                i10 = 0;
                alarmManager5.setExactAndAllowWhileIdle(0, j7, broadcast);
                alarmManager3 = alarmManager5;
            } catch (SecurityException unused) {
                alarmManager3.setAndAllowWhileIdle(i10, j7, broadcast);
            }
        }
    }

    public static void g(Context context, String str, String str2, int i2) {
        boolean canScheduleExactAlarms;
        c.b.c(context, "c");
        c.b.c(str, "kind");
        c.b.c(str2, "day");
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(AlarmManager.class);
        PendingIntent broadcast = PendingIntent.getBroadcast(context, 7, new Intent(context, (Class<?>) Alarm$Fire.class).putExtra("kind", str).putExtra("day", str2).putExtra("snoozed", true), 201326592);
        long currentTimeMillis = (i2 * 60000) + System.currentTimeMillis();
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                canScheduleExactAlarms = alarmManager.canScheduleExactAlarms();
                if (!canScheduleExactAlarms) {
                    alarmManager.setAndAllowWhileIdle(0, currentTimeMillis, broadcast);
                }
            }
            alarmManager.setExactAndAllowWhileIdle(0, currentTimeMillis, broadcast);
        } catch (SecurityException unused) {
            alarmManager.setAndAllowWhileIdle(0, currentTimeMillis, broadcast);
        }
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:177:0x0295, code lost:
    
        if (r26.equals("masa") == false) goto L254;
     */
    /* JADX WARN: Code restructure failed: missing block: B:260:0x0452, code lost:
    
        if (r26.equals(r5) == false) goto L254;
     */
    /* JADX WARN: Code restructure failed: missing block: B:47:0x006a, code lost:
    
        if (r26.equals("sabah") == false) goto L254;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x029d, code lost:
    
        if (j(r25, r27, r26) != 1) goto L114;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x029f, code lost:
    
        return null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x02a0, code lost:
    
        i(r13, "✅ قريتها", r26);
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x02af, code lost:
    
        if (c.b.a(r26, "sabah") == false) goto L118;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x02b1, code lost:
    
        r2 = "أذكار الصباح 🌄";
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x02b3, code lost:
    
        r10 = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x02be, code lost:
    
        if (c.b.a(r26, "sabah") == false) goto L123;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x02c0, code lost:
    
        r1 = "🌄";
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x02cf, code lost:
    
        return new g.c(r10, "اضغط تقرأها بالتطبيق، أو سجّلها لو قريتها", -10764033, r13, r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x02c4, code lost:
    
        r1 = "🌆";
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x02b5, code lost:
    
        r2 = "أذكار المساء 🌆";
     */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    /* JADX WARN: Removed duplicated region for block: B:11:0x0466 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:13:0x0467  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x045f  */
    /* JADX WARN: Removed duplicated region for block: B:8:0x045c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static g.c h(android.content.Context r25, java.lang.String r26, java.lang.String r27) {
        /*
            Method dump skipped, instructions count: 1396
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: g.e.h(android.content.Context, java.lang.String, java.lang.String):g.c");
    }

    /* JADX WARN: Type inference failed for: r3v1, types: [java.io.Serializable, java.lang.Object[]] */
    public static final void i(ArrayList arrayList, String str, String... strArr) {
        arrayList.add(new h.a(str, Arrays.copyOf(strArr, strArr.length)));
    }

    public static final int j(Context context, String str, String str2) {
        JSONObject optJSONObject;
        w wVar = w.f127a;
        c.b.c(context, "c");
        c.b.c(str, "day");
        c.b.c(str2, "id");
        JSONObject optJSONObject2 = wVar.b(context).optJSONObject("days");
        if (optJSONObject2 == null || (optJSONObject = optJSONObject2.optJSONObject(str)) == null) {
            return 0;
        }
        return optJSONObject.optInt(str2, 0);
    }

    public static int k(String str) {
        List n2 = n.f.n(str, new String[]{"-"});
        Calendar calendar = Calendar.getInstance();
        calendar.set(Integer.parseInt((String) n2.get(0)), Integer.parseInt((String) n2.get(1)) - 1, Integer.parseInt((String) n2.get(2)), 12, 0);
        return calendar.get(7);
    }
}
