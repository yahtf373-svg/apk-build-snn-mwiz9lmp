package g;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import com.abdullah.sunan.MainActivity;

/* loaded from: classes.dex */
public final class q implements LocationListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ k.d f114a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ LocationManager f115b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ MainActivity f116c;

    public q(k.d dVar, LocationManager locationManager, MainActivity mainActivity) {
        this.f114a = dVar;
        this.f115b = locationManager;
        this.f116c = mainActivity;
    }

    @Override // android.location.LocationListener
    public final void onLocationChanged(Location location) {
        c.b.c(location, "l");
        k.d dVar = this.f114a;
        if (dVar.f137a) {
            return;
        }
        dVar.f137a = true;
        this.f115b.removeUpdates(this);
        MainActivity mainActivity = MainActivity.f47c;
        this.f116c.d(location);
    }

    @Override // android.location.LocationListener
    public final void onProviderDisabled(String str) {
        c.b.c(str, "p");
    }

    @Override // android.location.LocationListener
    public final void onProviderEnabled(String str) {
        c.b.c(str, "p");
    }

    @Override // android.location.LocationListener
    public final void onStatusChanged(String str, int i2, Bundle bundle) {
    }
}
