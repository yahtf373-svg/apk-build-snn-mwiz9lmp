package g;

import com.abdullah.sunan.AlarmPage;
import com.abdullah.sunan.Ring;
import java.util.List;

/* loaded from: classes.dex */
public final class i extends k.c implements j.a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ AlarmPage f95a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f96b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f97c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f98d;

    public i(AlarmPage alarmPage, String str, String str2, int i2) {
        this.f95a = alarmPage;
        this.f96b = str;
        this.f97c = str2;
        this.f98d = i2;
    }

    @Override // j.a
    public final void a() {
        List list = e.f86a;
        String str = this.f97c;
        int i2 = this.f98d;
        AlarmPage alarmPage = this.f95a;
        e.g(alarmPage, this.f96b, str, i2);
        Ring ring = Ring.f50h;
        c.b.i(alarmPage);
        alarmPage.finish();
    }
}
