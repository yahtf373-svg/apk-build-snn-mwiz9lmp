package g;

import android.media.Ringtone;
import com.abdullah.sunan.Ring;
import org.chromium.support_lib_boundary.WebSettingsBoundaryInterface;

/* loaded from: classes.dex */
public final /* synthetic */ class v implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f124a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Ring f125b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f126c;

    public /* synthetic */ v(Ring ring, int i2, int i3) {
        this.f124a = i3;
        this.f125b = ring;
        this.f126c = i2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2 = this.f124a;
        int i3 = this.f126c;
        Ring ring = this.f125b;
        switch (i2) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                Ring ring2 = Ring.f50h;
                c.b.c(ring, "this$0");
                Ringtone ringtone = ring.f55c;
                if (ringtone != null) {
                    int i4 = 1;
                    if (ringtone.isPlaying()) {
                        ring.f53a.postDelayed(new v(ring, i3, i4), 1000L);
                        break;
                    }
                }
                ring.a(i3);
                break;
            default:
                Ring ring3 = Ring.f50h;
                c.b.c(ring, "this$0");
                ring.a(i3);
                break;
        }
    }
}
