package g;

import android.app.NotificationManager;
import com.abdullah.sunan.AlarmPage;
import com.abdullah.sunan.Ring;
import java.util.List;

/* loaded from: classes.dex */
public final class j extends k.c implements j.a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ AlarmPage f99a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f100b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f101c;

    public j(AlarmPage alarmPage, String str, String str2) {
        this.f99a = alarmPage;
        this.f100b = str;
        this.f101c = str2;
    }

    @Override // j.a
    public final void a() {
        Ring ring = Ring.f50h;
        AlarmPage alarmPage = this.f99a;
        c.b.i(alarmPage);
        List list = e.f86a;
        String str = this.f100b;
        String str2 = this.f101c;
        c h2 = e.h(alarmPage, str, str2);
        if (h2 != null) {
            try {
                ((NotificationManager) alarmPage.getSystemService(NotificationManager.class)).notify(e.d(str), e.a(alarmPage, "sunan", str, str2, h2).build());
            } catch (SecurityException unused) {
            }
        }
        alarmPage.finish();
    }
}
