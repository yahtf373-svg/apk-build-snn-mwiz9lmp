package g;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import com.abdullah.sunan.MainActivity;
import org.chromium.support_lib_boundary.WebSettingsBoundaryInterface;

/* loaded from: classes.dex */
public final /* synthetic */ class o implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f111a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ MainActivity f112b;

    public /* synthetic */ o(MainActivity mainActivity, int i2) {
        this.f111a = i2;
        this.f112b = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2 = this.f111a;
        MainActivity mainActivity = this.f112b;
        switch (i2) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                c.b.c(mainActivity, "this$0");
                try {
                    mainActivity.startActivity(new Intent("android.settings.REQUEST_SCHEDULE_EXACT_ALARM", Uri.parse("package:" + mainActivity.getPackageName())));
                    break;
                } catch (Exception unused) {
                    return;
                }
            case 1:
                c.b.c(mainActivity, "this$0");
                if (Build.VERSION.SDK_INT >= 33 && mainActivity.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != 0) {
                    mainActivity.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 3);
                    break;
                }
                break;
            case 2:
                c.b.c(mainActivity, "this$0");
                if (mainActivity.checkSelfPermission("android.permission.ACCESS_COARSE_LOCATION") == 0) {
                    mainActivity.c();
                    break;
                } else {
                    mainActivity.requestPermissions(new String[]{"android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"}, 5);
                    break;
                }
            default:
                c.b.c(mainActivity, "this$0");
                try {
                    mainActivity.startActivity(new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", Uri.parse("package:" + mainActivity.getPackageName())));
                    break;
                } catch (Exception unused2) {
                    return;
                }
        }
    }
}
