package g;

import android.content.Context;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class w {

    /* renamed from: a, reason: collision with root package name */
    public static final w f127a = new w();

    public final List a(Context context) {
        c.b.c(context, "c");
        JSONArray optJSONArray = b(context).optJSONArray("habits");
        if (optJSONArray == null) {
            return i.g.f133a;
        }
        int length = optJSONArray.length();
        l.c cVar = length <= Integer.MIN_VALUE ? l.c.f147d : new l.c(0, length - 1, 1);
        ArrayList arrayList = new ArrayList(i.b.j(cVar));
        Iterator it = cVar.iterator();
        while (((l.b) it).f145c) {
            l.b bVar = (l.b) it;
            int i2 = bVar.f146d;
            if (i2 != bVar.f144b) {
                bVar.f146d = bVar.f143a + i2;
            } else {
                if (!bVar.f145c) {
                    throw new NoSuchElementException();
                }
                bVar.f145c = false;
            }
            arrayList.add(optJSONArray.getString(i2));
        }
        return arrayList;
    }

    public final synchronized JSONObject b(Context context) {
        JSONObject jSONObject;
        String string;
        try {
            c.b.c(context, "c");
            try {
                string = context.getSharedPreferences("sunan", 0).getString("st", "{}");
            } catch (Exception unused) {
                jSONObject = new JSONObject();
            }
            if (string == null) {
                NullPointerException nullPointerException = new NullPointerException();
                c.b.h(nullPointerException);
                throw nullPointerException;
            }
            jSONObject = new JSONObject(string);
        } catch (Throwable th) {
            throw th;
        }
        return jSONObject;
    }

    public final synchronized void c(Context context, String str, String str2, int i2) {
        try {
            c.b.c(context, "c");
            c.b.c(str, "day");
            c.b.c(str2, "id");
            JSONObject b2 = b(context);
            JSONObject optJSONObject = b2.optJSONObject("days");
            if (optJSONObject == null) {
                optJSONObject = new JSONObject();
                b2.put("days", optJSONObject);
            }
            JSONObject optJSONObject2 = optJSONObject.optJSONObject(str);
            if (optJSONObject2 == null) {
                optJSONObject2 = new JSONObject();
                optJSONObject.put(str, optJSONObject2);
            }
            optJSONObject2.put(str2, i2);
            if (!b2.has("start")) {
                b2.put("start", str);
            }
            d(context, b2);
        } catch (Throwable th) {
            throw th;
        }
    }

    public final synchronized void d(Context context, JSONObject jSONObject) {
        c.b.c(context, "c");
        context.getSharedPreferences("sunan", 0).edit().putString("st", jSONObject.toString()).apply();
    }
}
