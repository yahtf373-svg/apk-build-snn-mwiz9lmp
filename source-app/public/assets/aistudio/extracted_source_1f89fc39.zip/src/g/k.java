package g;

import android.content.Intent;
import com.abdullah.sunan.MainActivity;
import org.chromium.support_lib_boundary.WebSettingsBoundaryInterface;

/* loaded from: classes.dex */
public final /* synthetic */ class k implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f102a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ MainActivity f103b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f104c;

    public /* synthetic */ k(MainActivity mainActivity, String str, int i2) {
        this.f102a = i2;
        this.f103b = mainActivity;
        this.f104c = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2 = this.f102a;
        String str = this.f104c;
        MainActivity mainActivity = this.f103b;
        switch (i2) {
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
                MainActivity mainActivity2 = MainActivity.f47c;
                c.b.c(mainActivity, "this$0");
                c.b.c(str, "$s");
                mainActivity.a().evaluateJavascript(str, null);
                break;
            default:
                c.b.c(mainActivity, "this$0");
                c.b.c(str, "$text");
                try {
                    mainActivity.startActivity(Intent.createChooser(new Intent("android.intent.action.SEND").setType("text/plain").putExtra("android.intent.extra.TEXT", str), "شارك"));
                    break;
                } catch (Exception unused) {
                    return;
                }
        }
    }
}
