package g;

import android.net.Uri;
import android.util.Log;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;

/* loaded from: classes.dex */
public final class r extends WebViewClient {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ e.c f117a;

    public r(e.c cVar) {
        this.f117a = cVar;
    }

    @Override // android.webkit.WebViewClient
    public final WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) {
        c.b.c(webView, "view");
        c.b.c(webResourceRequest, "request");
        Uri url = webResourceRequest.getUrl();
        for (e.b bVar : this.f117a.f76a) {
            bVar.getClass();
            boolean equals = url.getScheme().equals("http");
            String str = bVar.f74c;
            e.a aVar = ((!equals || bVar.f72a) && (url.getScheme().equals("http") || url.getScheme().equals("https")) && url.getAuthority().equals(bVar.f73b) && url.getPath().startsWith(str)) ? bVar.f75d : null;
            if (aVar != null) {
                String replaceFirst = url.getPath().replaceFirst(str, "");
                try {
                    f.a aVar2 = aVar.f71a;
                    aVar2.getClass();
                    String substring = (replaceFirst.length() <= 1 || replaceFirst.charAt(0) != '/') ? replaceFirst : replaceFirst.substring(1);
                    InputStream open = aVar2.f77a.getAssets().open(substring, 2);
                    if (substring.endsWith(".svgz")) {
                        open = new GZIPInputStream(open);
                    }
                    return new WebResourceResponse(f.a.a(replaceFirst), null, open);
                } catch (IOException e2) {
                    Log.e("WebViewAssetLoader", "Error opening asset path: " + replaceFirst, e2);
                    return new WebResourceResponse(null, null, null);
                }
            }
        }
        return null;
    }

    @Override // android.webkit.WebViewClient
    public final boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
        c.b.c(webView, "view");
        c.b.c(webResourceRequest, "request");
        if (webResourceRequest.isForMainFrame()) {
            return !c.b.a(webResourceRequest.getUrl().getHost(), "appassets.androidplatform.net");
        }
        return false;
    }
}
