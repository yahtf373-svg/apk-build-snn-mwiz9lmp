package g;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.os.Build;
import android.webkit.JavascriptInterface;
import com.abdullah.sunan.MainActivity;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONObject;
import org.json.JSONTokener;

/* loaded from: classes.dex */
public final class p {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ MainActivity f113a;

    public p(MainActivity mainActivity) {
        this.f113a = mainActivity;
    }

    @JavascriptInterface
    public final boolean askExact() {
        MainActivity mainActivity = this.f113a;
        return mainActivity.f49b.post(new o(mainActivity, 0));
    }

    @JavascriptInterface
    public final boolean askFull() {
        MainActivity mainActivity = this.f113a;
        return mainActivity.f49b.post(new o(mainActivity, 3));
    }

    @JavascriptInterface
    public final boolean askNotif() {
        MainActivity mainActivity = this.f113a;
        return mainActivity.f49b.post(new o(mainActivity, 1));
    }

    @JavascriptInterface
    public final boolean exactOk() {
        boolean canScheduleExactAlarms;
        if (Build.VERSION.SDK_INT >= 31) {
            canScheduleExactAlarms = ((AlarmManager) this.f113a.getSystemService(AlarmManager.class)).canScheduleExactAlarms();
            if (!canScheduleExactAlarms) {
                return false;
            }
        }
        return true;
    }

    @JavascriptInterface
    public final boolean fullOk() {
        boolean canUseFullScreenIntent;
        if (Build.VERSION.SDK_INT >= 34) {
            canUseFullScreenIntent = ((NotificationManager) this.f113a.getSystemService(NotificationManager.class)).canUseFullScreenIntent();
            if (!canUseFullScreenIntent) {
                return false;
            }
        }
        return true;
    }

    @JavascriptInterface
    public final boolean locate() {
        MainActivity mainActivity = this.f113a;
        return mainActivity.f49b.post(new o(mainActivity, 2));
    }

    @JavascriptInterface
    public final void mark(String str, String str2, int i2) {
        c.b.c(str, "day");
        c.b.c(str2, "id");
        w.f127a.c(this.f113a, str, str2, i2);
    }

    @JavascriptInterface
    public final boolean notifOk() {
        return Build.VERSION.SDK_INT < 33 || this.f113a.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == 0;
    }

    @JavascriptInterface
    public final void put(String str, String str2) {
        c.b.c(str, "k");
        c.b.c(str2, "json");
        w wVar = w.f127a;
        MainActivity mainActivity = this.f113a;
        synchronized (wVar) {
            JSONObject b2 = wVar.b(mainActivity);
            b2.put(str, new JSONTokener(str2).nextValue());
            wVar.d(mainActivity, b2);
        }
        List list = e.f86a;
        e.f(this.f113a);
    }

    @JavascriptInterface
    public final boolean share(String str) {
        c.b.c(str, "text");
        MainActivity mainActivity = this.f113a;
        return mainActivity.f49b.post(new k(mainActivity, str, 1));
    }

    @JavascriptInterface
    public final String state() {
        String jSONObject = w.f127a.b(this.f113a).toString();
        c.b.b(jSONObject, "toString(...)");
        return jSONObject;
    }

    @JavascriptInterface
    public final void test(String str) {
        c.b.c(str, "kind");
        List list = e.f86a;
        e.e(this.f113a, str, "1999-01-" + (((System.currentTimeMillis() / 1000) % 80) + 10));
    }

    @JavascriptInterface
    public final String times(String str) {
        c.b.c(str, "day");
        List n2 = n.f.n(str, new String[]{"-"});
        ArrayList arrayList = new ArrayList(i.b.j(n2));
        Iterator it = n2.iterator();
        while (it.hasNext()) {
            arrayList.add(Integer.valueOf(Integer.parseInt((String) it.next())));
        }
        int intValue = ((Number) arrayList.get(0)).intValue();
        int intValue2 = ((Number) arrayList.get(1)).intValue();
        int intValue3 = ((Number) arrayList.get(2)).intValue();
        w wVar = w.f127a;
        MainActivity mainActivity = this.f113a;
        c.b.c(mainActivity, "c");
        JSONObject optJSONObject = wVar.b(mainActivity).optJSONObject("loc");
        double optDouble = optJSONObject != null ? optJSONObject.optDouble("lat", 24.4672d) : 24.4672d;
        JSONObject optJSONObject2 = wVar.b(mainActivity).optJSONObject("loc");
        t e2 = c.b.e(intValue, intValue2, intValue3, optDouble, optJSONObject2 != null ? optJSONObject2.optDouble("lon", 39.6111d) : 39.6111d);
        String jSONObject = new JSONObject().put("fajr", e2.f118a).put("sunrise", e2.f119b).put("dhuhr", e2.f120c).put("asr", e2.f121d).put("maghrib", e2.f122e).put("isha", e2.f123f).toString();
        c.b.b(jSONObject, "toString(...)");
        return jSONObject;
    }
}
