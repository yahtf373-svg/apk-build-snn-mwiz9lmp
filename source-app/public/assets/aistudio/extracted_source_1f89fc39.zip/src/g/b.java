package g;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final long f78a;

    /* renamed from: b, reason: collision with root package name */
    public final String f79b;

    /* renamed from: c, reason: collision with root package name */
    public final String f80c;

    public b(long j2, String str, String str2) {
        this.f78a = j2;
        this.f79b = str;
        this.f80c = str2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return this.f78a == bVar.f78a && c.b.a(this.f79b, bVar.f79b) && c.b.a(this.f80c, bVar.f80c);
    }

    public final int hashCode() {
        return this.f80c.hashCode() + ((this.f79b.hashCode() + (Long.hashCode(this.f78a) * 31)) * 31);
    }

    public final String toString() {
        return "Ev(at=" + this.f78a + ", kind=" + this.f79b + ", day=" + this.f80c + ")";
    }
}
