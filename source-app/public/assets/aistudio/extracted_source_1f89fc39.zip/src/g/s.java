package g;

import android.util.Log;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;

/* loaded from: classes.dex */
public final class s extends WebChromeClient {
    @Override // android.webkit.WebChromeClient
    public final boolean onConsoleMessage(ConsoleMessage consoleMessage) {
        c.b.c(consoleMessage, "m");
        Log.i("sunan", consoleMessage.message() + " @" + consoleMessage.lineNumber());
        return true;
    }
}
