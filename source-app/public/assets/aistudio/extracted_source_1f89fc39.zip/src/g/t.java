package g;

/* loaded from: classes.dex */
public final class t {

    /* renamed from: a, reason: collision with root package name */
    public final long f118a;

    /* renamed from: b, reason: collision with root package name */
    public final long f119b;

    /* renamed from: c, reason: collision with root package name */
    public final long f120c;

    /* renamed from: d, reason: collision with root package name */
    public final long f121d;

    /* renamed from: e, reason: collision with root package name */
    public final long f122e;

    /* renamed from: f, reason: collision with root package name */
    public final long f123f;

    public t(long j2, long j3, long j4, long j5, long j6, long j7) {
        this.f118a = j2;
        this.f119b = j3;
        this.f120c = j4;
        this.f121d = j5;
        this.f122e = j6;
        this.f123f = j7;
    }
}
