package g;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final String f81a;

    /* renamed from: b, reason: collision with root package name */
    public final String f82b;

    /* renamed from: c, reason: collision with root package name */
    public final int f83c;

    /* renamed from: d, reason: collision with root package name */
    public final List f84d;

    /* renamed from: e, reason: collision with root package name */
    public final String f85e;

    public c(String str, String str2, int i2, ArrayList arrayList, String str3) {
        c.b.c(str, "title");
        this.f81a = str;
        this.f82b = str2;
        this.f83c = i2;
        this.f84d = arrayList;
        this.f85e = str3;
    }
}
