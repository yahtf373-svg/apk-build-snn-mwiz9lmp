package g;

import android.app.NotificationManager;
import com.abdullah.sunan.AlarmPage;
import com.abdullah.sunan.MainActivity;
import com.abdullah.sunan.Ring;
import java.util.List;

/* loaded from: classes.dex */
public final class h extends k.c implements j.a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String[] f91a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ AlarmPage f92b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f93c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ String f94d;

    public h(String[] strArr, AlarmPage alarmPage, String str, String str2) {
        this.f91a = strArr;
        this.f92b = alarmPage;
        this.f93c = str;
        this.f94d = str2;
    }

    @Override // j.a
    public final void a() {
        AlarmPage alarmPage;
        String str;
        for (String str2 : this.f91a) {
            boolean o = n.f.o(str2);
            w wVar = w.f127a;
            int i2 = 1;
            if (o) {
                alarmPage = this.f92b;
                str = this.f93c;
                str2 = str2.substring(1);
                c.b.b(str2, "substring(...)");
                i2 = -1;
            } else {
                alarmPage = this.f92b;
                str = this.f93c;
            }
            wVar.c(alarmPage, str, str2, i2);
        }
        NotificationManager notificationManager = (NotificationManager) this.f92b.getSystemService(NotificationManager.class);
        List list = e.f86a;
        notificationManager.cancel(e.d(this.f94d));
        MainActivity mainActivity = MainActivity.f47c;
        MainActivity mainActivity2 = MainActivity.f47c;
        if (mainActivity2 != null) {
            mainActivity2.b("window.onState&&onState()");
        }
        Ring ring = Ring.f50h;
        c.b.i(this.f92b);
        this.f92b.finish();
    }
}
