package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import d.b;
import d.c;
import d.d;

/* loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(b bVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        d dVar = remoteActionCompat.f26a;
        if (bVar.e(1)) {
            dVar = bVar.g();
        }
        remoteActionCompat.f26a = (IconCompat) dVar;
        CharSequence charSequence = remoteActionCompat.f27b;
        if (bVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((c) bVar).f64e);
        }
        remoteActionCompat.f27b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f28c;
        if (bVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((c) bVar).f64e);
        }
        remoteActionCompat.f28c = charSequence2;
        remoteActionCompat.f29d = (PendingIntent) bVar.f(remoteActionCompat.f29d, 4);
        boolean z = remoteActionCompat.f30e;
        if (bVar.e(5)) {
            z = ((c) bVar).f64e.readInt() != 0;
        }
        remoteActionCompat.f30e = z;
        boolean z2 = remoteActionCompat.f31f;
        if (bVar.e(6)) {
            z2 = ((c) bVar).f64e.readInt() != 0;
        }
        remoteActionCompat.f31f = z2;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, b bVar) {
        bVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f26a;
        bVar.h(1);
        bVar.i(iconCompat);
        CharSequence charSequence = remoteActionCompat.f27b;
        bVar.h(2);
        Parcel parcel = ((c) bVar).f64e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f28c;
        bVar.h(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.f29d;
        bVar.h(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z = remoteActionCompat.f30e;
        bVar.h(5);
        parcel.writeInt(z ? 1 : 0);
        boolean z2 = remoteActionCompat.f31f;
        bVar.h(6);
        parcel.writeInt(z2 ? 1 : 0);
    }
}
