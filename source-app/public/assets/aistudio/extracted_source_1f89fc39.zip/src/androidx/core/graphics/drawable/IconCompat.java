package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcelable;
import androidx.versionedparcelable.CustomVersionedParcelable;

/* loaded from: classes.dex */
public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: k, reason: collision with root package name */
    public static final PorterDuff.Mode f32k = PorterDuff.Mode.SRC_IN;

    /* renamed from: b, reason: collision with root package name */
    public Object f34b;

    /* renamed from: j, reason: collision with root package name */
    public String f42j;

    /* renamed from: a, reason: collision with root package name */
    public int f33a = -1;

    /* renamed from: c, reason: collision with root package name */
    public byte[] f35c = null;

    /* renamed from: d, reason: collision with root package name */
    public Parcelable f36d = null;

    /* renamed from: e, reason: collision with root package name */
    public int f37e = 0;

    /* renamed from: f, reason: collision with root package name */
    public int f38f = 0;

    /* renamed from: g, reason: collision with root package name */
    public ColorStateList f39g = null;

    /* renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f40h = f32k;

    /* renamed from: i, reason: collision with root package name */
    public String f41i = null;

    /* JADX WARN: Removed duplicated region for block: B:39:0x00fd  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x010d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.String toString() {
        /*
            Method dump skipped, instructions count: 322
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompat.toString():java.lang.String");
    }
}
