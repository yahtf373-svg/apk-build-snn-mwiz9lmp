package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import d.b;
import d.c;
import java.nio.charset.Charset;
import org.chromium.support_lib_boundary.WebSettingsBoundaryInterface;

/* loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(b bVar) {
        IconCompat iconCompat = new IconCompat();
        int i2 = iconCompat.f33a;
        if (bVar.e(1)) {
            i2 = ((c) bVar).f64e.readInt();
        }
        iconCompat.f33a = i2;
        byte[] bArr = iconCompat.f35c;
        if (bVar.e(2)) {
            Parcel parcel = ((c) bVar).f64e;
            int readInt = parcel.readInt();
            if (readInt < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[readInt];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f35c = bArr;
        iconCompat.f36d = bVar.f(iconCompat.f36d, 3);
        int i3 = iconCompat.f37e;
        if (bVar.e(4)) {
            i3 = ((c) bVar).f64e.readInt();
        }
        iconCompat.f37e = i3;
        int i4 = iconCompat.f38f;
        if (bVar.e(5)) {
            i4 = ((c) bVar).f64e.readInt();
        }
        iconCompat.f38f = i4;
        iconCompat.f39g = (ColorStateList) bVar.f(iconCompat.f39g, 6);
        String str = iconCompat.f41i;
        if (bVar.e(7)) {
            str = ((c) bVar).f64e.readString();
        }
        iconCompat.f41i = str;
        String str2 = iconCompat.f42j;
        if (bVar.e(8)) {
            str2 = ((c) bVar).f64e.readString();
        }
        iconCompat.f42j = str2;
        iconCompat.f40h = PorterDuff.Mode.valueOf(iconCompat.f41i);
        switch (iconCompat.f33a) {
            case -1:
                Parcelable parcelable = iconCompat.f36d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                iconCompat.f34b = parcelable;
                return iconCompat;
            case WebSettingsBoundaryInterface.ForceDarkBehavior.FORCE_DARK_ONLY /* 0 */:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.f36d;
                if (parcelable2 != null) {
                    iconCompat.f34b = parcelable2;
                } else {
                    byte[] bArr3 = iconCompat.f35c;
                    iconCompat.f34b = bArr3;
                    iconCompat.f33a = 3;
                    iconCompat.f37e = 0;
                    iconCompat.f38f = bArr3.length;
                }
                return iconCompat;
            case 2:
            case 4:
            case 6:
                String str3 = new String(iconCompat.f35c, Charset.forName("UTF-16"));
                iconCompat.f34b = str3;
                if (iconCompat.f33a == 2 && iconCompat.f42j == null) {
                    iconCompat.f42j = str3.split(":", -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.f34b = iconCompat.f35c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, b bVar) {
        bVar.getClass();
        iconCompat.f41i = iconCompat.f40h.name();
        switch (iconCompat.f33a) {
            case -1:
                iconCompat.f36d = (Parcelable) iconCompat.f34b;
                break;
            case 1:
            case 5:
                iconCompat.f36d = (Parcelable) iconCompat.f34b;
                break;
            case 2:
                iconCompat.f35c = ((String) iconCompat.f34b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f35c = (byte[]) iconCompat.f34b;
                break;
            case 4:
            case 6:
                iconCompat.f35c = iconCompat.f34b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i2 = iconCompat.f33a;
        if (-1 != i2) {
            bVar.h(1);
            ((c) bVar).f64e.writeInt(i2);
        }
        byte[] bArr = iconCompat.f35c;
        if (bArr != null) {
            bVar.h(2);
            int length = bArr.length;
            Parcel parcel = ((c) bVar).f64e;
            parcel.writeInt(length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f36d;
        if (parcelable != null) {
            bVar.h(3);
            ((c) bVar).f64e.writeParcelable(parcelable, 0);
        }
        int i3 = iconCompat.f37e;
        if (i3 != 0) {
            bVar.h(4);
            ((c) bVar).f64e.writeInt(i3);
        }
        int i4 = iconCompat.f38f;
        if (i4 != 0) {
            bVar.h(5);
            ((c) bVar).f64e.writeInt(i4);
        }
        ColorStateList colorStateList = iconCompat.f39g;
        if (colorStateList != null) {
            bVar.h(6);
            ((c) bVar).f64e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f41i;
        if (str != null) {
            bVar.h(7);
            ((c) bVar).f64e.writeString(str);
        }
        String str2 = iconCompat.f42j;
        if (str2 != null) {
            bVar.h(8);
            ((c) bVar).f64e.writeString(str2);
        }
    }
}
