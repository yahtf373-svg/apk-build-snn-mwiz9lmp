package androidx.versionedparcelable;

import d.d;

/* loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements d {
}
