package androidx.lifecycle;

/* loaded from: classes.dex */
class Lifecycling$1 {
}
