package e;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final List f76a;

    public c(ArrayList arrayList) {
        this.f76a = arrayList;
    }
}
