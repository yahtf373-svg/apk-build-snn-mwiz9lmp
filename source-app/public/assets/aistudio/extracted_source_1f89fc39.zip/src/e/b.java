package e;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final boolean f72a;

    /* renamed from: b, reason: collision with root package name */
    public final String f73b;

    /* renamed from: c, reason: collision with root package name */
    public final String f74c;

    /* renamed from: d, reason: collision with root package name */
    public final a f75d;

    public b(String str, a aVar) {
        if (str.isEmpty() || str.charAt(0) != '/') {
            throw new IllegalArgumentException("Path should start with a slash '/'.");
        }
        if (!str.endsWith("/")) {
            throw new IllegalArgumentException("Path should end with a slash '/'");
        }
        this.f73b = "appassets.androidplatform.net";
        this.f74c = str;
        this.f72a = false;
        this.f75d = aVar;
    }
}
