package l;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class b implements Iterator {

    /* renamed from: a, reason: collision with root package name */
    public final int f143a;

    /* renamed from: b, reason: collision with root package name */
    public final int f144b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f145c;

    /* renamed from: d, reason: collision with root package name */
    public int f146d;

    public b(int i2, int i3, int i4) {
        this.f143a = i4;
        this.f144b = i3;
        boolean z = true;
        if (i4 <= 0 ? i2 < i3 : i2 > i3) {
            z = false;
        }
        this.f145c = z;
        this.f146d = z ? i2 : i3;
    }

    @Override // java.util.Iterator
    /* renamed from: a, reason: merged with bridge method [inline-methods] */
    public final Object next() {
        int i2 = this.f146d;
        if (i2 != this.f144b) {
            this.f146d = this.f143a + i2;
        } else {
            if (!this.f145c) {
                throw new NoSuchElementException();
            }
            this.f145c = false;
        }
        return Integer.valueOf(i2);
    }

    public final void b() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f145c;
    }

    @Override // java.util.Iterator
    public final /* bridge */ /* synthetic */ void remove() {
        b();
        throw null;
    }
}
