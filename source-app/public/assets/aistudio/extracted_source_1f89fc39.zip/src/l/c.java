package l;

/* loaded from: classes.dex */
public final class c extends a {

    /* renamed from: d, reason: collision with root package name */
    public static final c f147d = new c(1, 0, 1);

    public final boolean equals(Object obj) {
        if (obj instanceof c) {
            if (!isEmpty() || !((c) obj).isEmpty()) {
                c cVar = (c) obj;
                if (this.f140a == cVar.f140a) {
                    if (this.f141b == cVar.f141b) {
                    }
                }
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (this.f140a * 31) + this.f141b;
    }

    public final boolean isEmpty() {
        return this.f140a > this.f141b;
    }

    public final String toString() {
        return this.f140a + ".." + this.f141b;
    }
}
