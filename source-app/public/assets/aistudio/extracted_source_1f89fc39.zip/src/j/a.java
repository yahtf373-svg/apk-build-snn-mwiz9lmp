package j;

/* loaded from: classes.dex */
public interface a {
    void a();
}
